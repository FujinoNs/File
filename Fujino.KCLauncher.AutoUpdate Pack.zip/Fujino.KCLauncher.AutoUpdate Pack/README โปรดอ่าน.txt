วิธีใช้งาน:
นำไฟล์ที่ Launcher แจ้งว่าหายไป นำไปใส่ในที่ตำแหน่งของ Launcher 
โดยคลิ๊กขวาที่ Icon Launcher และคลิ๊ก Open file location
และหากไฟล์ยังคงหายอยู่โปรดเปลี่ยนตำแหน่งติดตั้ง Launcher! 
หรือเพิ่มข้อยกเว้นเพิ่มข้อยกเว้น เพื่อไม่ให้ Antivirus ทำการลบไฟล์ทิ้งอัตโนมัติ : https://support.microsoft.com/en-us/windows/add-an-exclusion-to-windows-security-811816c0-4dfd-af4a-47e4-c301afe13b26

How to use it:
Take the file that the launcher says is missing and put it in the location of the launcher.
To do so, right click on Icon Launcher and click Open file location.
And if the files are still missing, please change the launcher install location!
Or add an exception to add an exception to prevent Antivirus from automatically deleting files: https://support.microsoft.com/en-us/windows/add-an-exclusion-to-windows-security-811816c0-4dfd-af4a-47e4-c301afe13b26